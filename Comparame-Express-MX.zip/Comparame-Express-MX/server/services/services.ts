import { Request, Response } from "express";
import { storage } from "../storage";
import { ServiceCategory, ServiceProvider } from "@shared/schema";

export async function getServiceCategories(req: Request, res: Response) {
  try {
    const categories = await storage.getServiceCategories();
    res.json(categories);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    res.status(500).json({ message });
  }
}

export async function getServiceProviders(req: Request, res: Response) {
  try {
    const categorySlug = req.params.categorySlug;
    const zipCode = req.query.zip as string | undefined;
    
    const providers = await storage.getServiceProviders(categorySlug, zipCode);
    
    // Format provider ratings for display (convert from integer to decimal)
    const formattedProviders = providers.map(provider => ({
      ...provider,
      rating: provider.rating / 10
    }));
    
    res.json(formattedProviders);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    res.status(500).json({ message });
  }
}
