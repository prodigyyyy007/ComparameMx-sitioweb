import { Request, Response } from "express";
import { storage } from "../storage";
import { insertContactMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function contactHandler(req: Request, res: Response) {
  try {
    // Validate the request body
    const validatedData = insertContactMessageSchema.safeParse(req.body);
    
    if (!validatedData.success) {
      return res.status(400).json({ 
        message: "Invalid request data", 
        errors: validatedData.error.format() 
      });
    }
    
    // Store the contact message
    const message = await storage.createContactMessage(validatedData.data);
    
    // In a real application, we would likely send an email notification here
    // But for this prototype we'll just log the message
    console.log("New contact message received:", {
      from: message.name,
      email: message.email,
      subject: message.subject
    });
    
    return res.status(201).json({ 
      message: "Contact message received successfully",
      id: message.id
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error processing contact message";
    return res.status(500).json({ message });
  }
}
