import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertContactMessageSchema } from "@shared/schema";
import { contactHandler } from "./services/contact";
import { getServiceCategories, getServiceProviders } from "./services/services";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  app.get("/api/categories", getServiceCategories);
  
  app.get("/api/providers", getServiceProviders);
  
  app.get("/api/providers/:categorySlug", getServiceProviders);
  
  app.post("/api/contact", contactHandler);

  const httpServer = createServer(app);

  return httpServer;
}
