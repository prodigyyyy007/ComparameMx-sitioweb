import { 
  User, 
  InsertUser, 
  ServiceCategory, 
  InsertServiceCategory,
  ServiceProvider,
  InsertServiceProvider,
  ContactMessage,
  InsertContactMessage
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Service category methods
  getServiceCategories(): Promise<ServiceCategory[]>;
  getServiceCategoryBySlug(slug: string): Promise<ServiceCategory | undefined>;
  createServiceCategory(category: InsertServiceCategory): Promise<ServiceCategory>;

  // Service provider methods
  getServiceProviders(categorySlug?: string, zipCode?: string): Promise<ServiceProvider[]>;
  getServiceProviderById(id: number): Promise<ServiceProvider | undefined>;
  createServiceProvider(provider: InsertServiceProvider): Promise<ServiceProvider>;

  // Contact methods
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
  markContactMessageAsRead(id: number): Promise<ContactMessage | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private serviceCategories: Map<number, ServiceCategory>;
  private serviceProviders: Map<number, ServiceProvider>;
  private contactMessages: Map<number, ContactMessage>;
  
  private userId: number;
  private categoryId: number;
  private providerId: number;
  private messageId: number;

  constructor() {
    this.users = new Map();
    this.serviceCategories = new Map();
    this.serviceProviders = new Map();
    this.contactMessages = new Map();
    
    this.userId = 1;
    this.categoryId = 1;
    this.providerId = 1;
    this.messageId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample service categories
    const categories: InsertServiceCategory[] = [
      {
        name: "Internet & Cable",
        slug: "internet",
        icon: "fa-wifi",
        iconColor: "bg-blue-100 text-primary",
        description: "Compare high-speed internet and TV packages from providers in your area.",
        order: 1
      },
      {
        name: "Home Insurance",
        slug: "insurance",
        icon: "fa-house-damage",
        iconColor: "bg-green-100 text-secondary",
        description: "Find affordable home insurance policies with the coverage you need.",
        order: 2
      },
      {
        name: "Energy Utilities",
        slug: "electricity",
        icon: "fa-bolt",
        iconColor: "bg-yellow-100 text-yellow-600",
        description: "Compare electricity and gas providers to find the best rates and plans.",
        order: 3
      },
      {
        name: "Home Security",
        slug: "security",
        icon: "fa-shield-alt",
        iconColor: "bg-red-100 text-red-600",
        description: "Protect your new home with top-rated security systems and monitoring.",
        order: 4
      },
      {
        name: "Lawn & Garden",
        slug: "lawn",
        icon: "fa-leaf",
        iconColor: "bg-green-100 text-green-600",
        description: "Find reliable lawn care and landscaping services in your neighborhood.",
        order: 5
      },
      {
        name: "Home Warranty",
        slug: "warranty",
        icon: "fa-tools",
        iconColor: "bg-purple-100 text-purple-600",
        description: "Protect major systems and appliances with comprehensive warranty plans.",
        order: 6
      }
    ];

    categories.forEach(category => this.createServiceCategory(category));

    // Sample internet and services providers (Mexico)
    const providers: InsertServiceProvider[] = [
      // Internet Providers
      {
        categoryId: 1,
        name: "Telmex Infinitum",
        type: "Fibra Óptica",
        icon: "fa-wifi",
        iconColor: "bg-blue-100",
        price: "$599/mes",
        priceNote: "con instalación incluida",
        speed: "200 Mbps",
        speedNote: "simétrico de subida",
        dataCap: "Ilimitado",
        rating: 42,
        zipCodes: ['01000', '03100', '06100', '11000', '64000']
      },
      {
        categoryId: 1,
        name: "Totalplay",
        type: "Fibra Óptica",
        icon: "fa-bolt",
        iconColor: "bg-orange-100",
        price: "$699/mes",
        priceNote: "incluye TV y teléfono",
        speed: "300 Mbps",
        speedNote: "300 Mbps subida",
        dataCap: "Ilimitado",
        rating: 46,
        zipCodes: ['01000', '03100', '06100', '44100', '64000']
      },
      {
        categoryId: 1,
        name: "Izzi",
        type: "Cable",
        icon: "fa-globe",
        iconColor: "bg-red-100",
        price: "$549/mes",
        priceNote: "primer año con descuento",
        speed: "150 Mbps",
        speedNote: "hasta 15 Mbps subida",
        dataCap: "Ilimitado",
        rating: 39,
        zipCodes: ['01000', '03100', '06100', '44100', '20000']
      },
      {
        categoryId: 1,
        name: "Megacable",
        type: "Cable",
        icon: "fa-signal",
        iconColor: "bg-green-100",
        price: "$489/mes",
        priceNote: "incluye equipo en comodato",
        speed: "100 Mbps",
        speedNote: "hasta 10 Mbps subida",
        dataCap: "Ilimitado",
        rating: 37,
        zipCodes: ['44100', '20000', '80000', '25000']
      },
      // Insurance Providers
      {
        categoryId: 2,
        name: "BBVA Seguros",
        type: "Seguro Integral",
        icon: "fa-shield",
        iconColor: "bg-blue-100",
        price: "$3,500/año",
        priceNote: "cobertura amplia",
        speed: null,
        speedNote: null,
        dataCap: "Hasta $2M MXN",
        rating: 44,
        zipCodes: ['01000', '03100', '06100', '11000', '44100', '64000']
      },
      {
        categoryId: 2,
        name: "GNP Seguros",
        type: "Seguro Hogar",
        icon: "fa-home",
        iconColor: "bg-green-100",
        price: "$4,200/año",
        priceNote: "incluye responsabilidad civil",
        speed: null,
        speedNote: null,
        dataCap: "Hasta $3M MXN",
        rating: 47,
        zipCodes: ['01000', '03100', '06100', '11000', '44100', '64000']
      },
      // Electricity Providers
      {
        categoryId: 3,
        name: "CFE Suministrador",
        type: "Tarifa DAC",
        icon: "fa-bolt",
        iconColor: "bg-yellow-100",
        price: "$0.85/kWh",
        priceNote: "tarifa doméstica alta",
        speed: null,
        speedNote: null,
        dataCap: "Sin límite",
        rating: 35,
        zipCodes: ['01000', '03100', '06100', '11000', '44100', '64000']
      },
      {
        categoryId: 3,
        name: "Total Energía",
        type: "Suministro Calificado",
        icon: "fa-leaf",
        iconColor: "bg-green-100",
        price: "$0.79/kWh",
        priceNote: "energía 100% renovable",
        speed: null,
        speedNote: null,
        dataCap: "Contrato mínimo 1 año",
        rating: 41,
        zipCodes: ['01000', '03100', '06100', '11000']
      }
    ];

    providers.forEach(provider => this.createServiceProvider(provider));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Service category methods
  async getServiceCategories(): Promise<ServiceCategory[]> {
    return Array.from(this.serviceCategories.values())
      .sort((a, b) => a.order - b.order);
  }

  async getServiceCategoryBySlug(slug: string): Promise<ServiceCategory | undefined> {
    return Array.from(this.serviceCategories.values()).find(
      (category) => category.slug === slug,
    );
  }

  async createServiceCategory(insertCategory: InsertServiceCategory): Promise<ServiceCategory> {
    const id = this.categoryId++;
    const category: ServiceCategory = { ...insertCategory, id, order: insertCategory.order || 0 };
    this.serviceCategories.set(id, category);
    return category;
  }

  // Service provider methods
  async getServiceProviders(categorySlug?: string, zipCode?: string): Promise<ServiceProvider[]> {
    let providers = Array.from(this.serviceProviders.values());
    
    if (categorySlug) {
      const category = await this.getServiceCategoryBySlug(categorySlug);
      if (category) {
        providers = providers.filter(provider => provider.categoryId === category.id);
      }
    }
    
    if (zipCode) {
      providers = providers.filter(provider => 
        provider.zipCodes && provider.zipCodes.includes(zipCode)
      );
    }
    
    return providers.sort((a, b) => b.rating - a.rating);
  }

  async getServiceProviderById(id: number): Promise<ServiceProvider | undefined> {
    return this.serviceProviders.get(id);
  }

  async createServiceProvider(insertProvider: InsertServiceProvider): Promise<ServiceProvider> {
    const id = this.providerId++;
    const provider: ServiceProvider = { 
      ...insertProvider, 
      id,
      priceNote: insertProvider.priceNote || null,
      speed: insertProvider.speed || null,
      speedNote: insertProvider.speedNote || null,
      dataCap: insertProvider.dataCap || null,
      zipCodes: insertProvider.zipCodes || null
    };
    this.serviceProviders.set(id, provider);
    return provider;
  }

  // Contact methods
  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.messageId++;
    const message: ContactMessage = { 
      ...insertMessage, 
      id, 
      createdAt: new Date(), 
      isRead: false 
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values())
      .sort((a, b) => {
        const aTime = a.createdAt?.getTime() || 0;
        const bTime = b.createdAt?.getTime() || 0;
        return bTime - aTime;
      });
  }

  async markContactMessageAsRead(id: number): Promise<ContactMessage | undefined> {
    const message = this.contactMessages.get(id);
    if (message) {
      const updatedMessage = { ...message, isRead: true };
      this.contactMessages.set(id, updatedMessage);
      return updatedMessage;
    }
    return undefined;
  }
}

export const storage = new MemStorage();