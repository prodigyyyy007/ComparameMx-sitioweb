import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

type Resource = {
  id: string;
  type: "guide" | "article" | "tool";
  title: string;
  description: string;
  image: string;
  link: string;
  typeColor: string;
};

export default function ResourcesList() {
  const resources: Resource[] = [
    {
      id: "moving-checklist",
      type: "guide",
      title: "The Ultimate Moving Checklist for New Homeowners",
      description: "A comprehensive checklist to ensure you don't miss anything important during your move.",
      image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      link: "/resources/moving-checklist",
      typeColor: "text-primary"
    },
    {
      id: "after-buying",
      type: "article",
      title: "10 Things to Do Immediately After Buying a Home",
      description: "Essential tasks to tackle right after you get the keys to your new home.",
      image: "https://images.unsplash.com/photo-1582063289852-62e3ba2747f8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      link: "/resources/after-buying-home",
      typeColor: "text-secondary"
    },
    {
      id: "budget-calculator",
      type: "tool",
      title: "Home Service Budget Calculator",
      description: "Plan your monthly expenses for all home services with our interactive calculator.",
      image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      link: "/resources/budget-calculator",
      typeColor: "text-yellow-600"
    },
    {
      id: "smart-home",
      type: "guide",
      title: "Smart Home Essentials for New Homeowners",
      description: "Discover the must-have smart home devices that enhance comfort and security.",
      image: "https://images.unsplash.com/photo-1558002038-1055907df827?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      link: "/resources/smart-home-essentials",
      typeColor: "text-primary"
    },
    {
      id: "insurance-guide",
      type: "article",
      title: "Understanding Home Insurance: A Beginner's Guide",
      description: "Learn about different types of coverage and how to choose the right plan for your home.",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      link: "/resources/home-insurance-guide",
      typeColor: "text-secondary"
    },
    {
      id: "maintenance-checklist",
      type: "tool",
      title: "Seasonal Home Maintenance Checklist",
      description: "A customizable maintenance schedule to keep your home in top condition year-round.",
      image: "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      link: "/resources/maintenance-checklist",
      typeColor: "text-yellow-600"
    }
  ];

  const getActionText = (type: string) => {
    switch (type) {
      case "guide": return "Read the guide";
      case "article": return "Read the article";
      case "tool": return type === "budget-calculator" ? "Use the calculator" : "Get the checklist";
      default: return "Learn more";
    }
  };

  return (
    <section id="resources" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Resources for New Homeowners</h2>
          <p className="text-neutral-600 max-w-3xl mx-auto">Check out our guides, articles, and tools to help you make the most of your new home.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {resources.map((resource) => (
            <article key={resource.id} className="bg-white rounded-xl overflow-hidden shadow-md border border-neutral-200 hover:shadow-lg transition">
              <img 
                src={resource.image} 
                alt={resource.title} 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className={`text-xs ${resource.typeColor} font-medium mb-2 uppercase tracking-wider`}>
                  {resource.type}
                </div>
                <h3 className="text-xl font-semibold mb-2">{resource.title}</h3>
                <p className="text-neutral-600 mb-4">{resource.description}</p>
                <Link href={resource.link} className="text-primary font-medium hover:underline inline-flex items-center">
                  {getActionText(resource.type)}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </article>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Link href="/resources" className="inline-flex items-center text-primary font-medium hover:underline">
            Browse all resources
            <i className="fas fa-chevron-right ml-2 text-sm"></i>
          </Link>
        </div>
      </div>
    </section>
  );
}
