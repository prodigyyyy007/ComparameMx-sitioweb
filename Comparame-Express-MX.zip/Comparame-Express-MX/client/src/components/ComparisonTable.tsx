import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Filter, SortAsc, MapPin, ExternalLink } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

type Provider = {
  id: string;
  name: string;
  type: string;
  icon: string;
  iconColor: string;
  price: string;
  priceNote: string;
  speed: string;
  speedNote: string;
  dataCap: string;
  rating: number;
};

interface ComparisonTableProps {
  serviceType?: string;
  zip?: string;
}

export default function ComparisonTable({ serviceType = "internet", zip = "" }: ComparisonTableProps) {
  const [filterZip, setFilterZip] = useState(zip);
  const [selectedView, setSelectedView] = useState("All Providers");

  const { data: providers, isLoading } = useQuery({
    queryKey: ['/api/providers', serviceType, filterZip],
    enabled: !!serviceType
  });

  const renderProviderIcon = (provider: Provider) => {
    return (
      <div className={`w-10 h-10 flex-shrink-0 mr-3 ${provider.iconColor} rounded-full flex items-center justify-center`}>
        <i className={`fas ${provider.icon}`}></i>
      </div>
    );
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={`star-${i}`} className="fas fa-star"></i>);
    }

    if (hasHalfStar) {
      stars.push(<i key="half-star" className="fas fa-star-half-alt"></i>);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star"></i>);
    }

    return (
      <span className="text-yellow-500 mr-1">
        {stars}
      </span>
    );
  };

  // Fallback providers for when API hasn't loaded yet
  const fallbackProviders: Provider[] = [
    {
      id: "1",
      name: "Xfinity",
      type: "Cable",
      icon: "fa-bolt",
      iconColor: "bg-blue-100",
      price: "$39.99/mo",
      priceNote: "for 12 mos. + equip. & fees",
      speed: "300 Mbps",
      speedNote: "up to 10 Mbps upload",
      dataCap: "1.2 TB",
      rating: 4.5
    },
    {
      id: "2",
      name: "Verizon Fios",
      type: "Fiber",
      icon: "fa-globe",
      iconColor: "bg-red-100",
      price: "$49.99/mo",
      priceNote: "w/ Auto Pay + taxes & equip",
      speed: "500 Mbps",
      speedNote: "500 Mbps upload",
      dataCap: "Unlimited",
      rating: 4.8
    },
    {
      id: "3",
      name: "AT&T Fiber",
      type: "Fiber",
      icon: "fa-wifi",
      iconColor: "bg-green-100",
      price: "$55.00/mo",
      priceNote: "plus taxes & equip. fee",
      speed: "1000 Mbps",
      speedNote: "1000 Mbps upload",
      dataCap: "Unlimited",
      rating: 4.2
    },
    {
      id: "4",
      name: "Spectrum",
      type: "Cable",
      icon: "fa-signal",
      iconColor: "bg-purple-100",
      price: "$49.99/mo",
      priceNote: "for 12 mos. when bundled",
      speed: "200 Mbps",
      speedNote: "up to 10 Mbps upload",
      dataCap: "Unlimited",
      rating: 3.7
    }
  ];

  const displayProviders = providers || fallbackProviders;

  return (
    <section className="py-16 bg-neutral-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Compare {serviceType.charAt(0).toUpperCase() + serviceType.slice(1)} Providers in Your Area</h2>
          <p className="text-neutral-600 max-w-3xl mx-auto">See side-by-side comparisons of speeds, prices, and reviews for providers available at your address.</p>
        </div>
        
        <Card className="bg-white rounded-xl shadow-lg border border-neutral-200 overflow-hidden mb-8">
          <div className="px-6 py-4 bg-neutral-50 border-b border-neutral-200">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <h3 className="font-semibold">Provider Comparison</h3>
              
              <div className="flex flex-wrap gap-3">
                <div className="inline-flex rounded-md shadow-sm">
                  <Button variant="outline" size="sm" className="rounded-l-lg rounded-r-none">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" size="sm" className="rounded-l-none rounded-r-lg">
                    <SortAsc className="h-4 w-4 mr-2" />
                    Sort
                  </Button>
                </div>
                
                <Select value={selectedView} onValueChange={setSelectedView}>
                  <SelectTrigger className="px-3 py-2 text-sm border border-neutral-300 rounded-lg text-neutral-700 bg-white h-9">
                    <SelectValue placeholder="All Providers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All Providers">All Providers</SelectItem>
                    <SelectItem value="Top Rated">Top Rated</SelectItem>
                    <SelectItem value="Fastest Speeds">Fastest Speeds</SelectItem>
                    <SelectItem value="Best Value">Best Value</SelectItem>
                  </SelectContent>
                </Select>
                
                <div className="relative">
                  <MapPin className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                  <Input 
                    type="text" 
                    placeholder="ZIP Code" 
                    className="pl-9 pr-3 py-2 text-sm border border-neutral-300 rounded-lg text-neutral-700 bg-white w-28"
                    value={filterZip}
                    onChange={(e) => setFilterZip(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-neutral-50">
                <TableRow>
                  <TableHead className="px-6 py-3 text-xs text-neutral-700 uppercase">Provider</TableHead>
                  <TableHead className="px-6 py-3 text-xs text-neutral-700 uppercase">Starting Price</TableHead>
                  <TableHead className="px-6 py-3 text-xs text-neutral-700 uppercase">Download Speed</TableHead>
                  <TableHead className="px-6 py-3 text-xs text-neutral-700 uppercase">Data Cap</TableHead>
                  <TableHead className="px-6 py-3 text-xs text-neutral-700 uppercase">Rating</TableHead>
                  <TableHead className="px-6 py-3 text-xs text-neutral-700 uppercase">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {displayProviders.map((provider) => (
                  <TableRow key={provider.id} className="bg-white border-b hover:bg-neutral-50">
                    <TableCell className="px-6 py-4 font-medium">
                      <div className="flex items-center">
                        {renderProviderIcon(provider)}
                        <div>
                          <div className="font-medium">{provider.name}</div>
                          <div className="text-xs text-neutral-500">{provider.type}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="px-6 py-4">
                      <div className="font-medium">{provider.price}</div>
                      <div className="text-xs text-neutral-500">{provider.priceNote}</div>
                    </TableCell>
                    <TableCell className="px-6 py-4">
                      <div className="font-medium">{provider.speed}</div>
                      <div className="text-xs text-neutral-500">{provider.speedNote}</div>
                    </TableCell>
                    <TableCell className="px-6 py-4">
                      <div>{provider.dataCap}</div>
                    </TableCell>
                    <TableCell className="px-6 py-4">
                      <div className="flex items-center">
                        {renderStars(provider.rating)}
                        <span className="ml-1">{provider.rating}</span>
                      </div>
                    </TableCell>
                    <TableCell className="px-6 py-4">
                      <Button className="px-4 py-2 bg-primary text-white text-sm font-medium rounded-lg hover:bg-primary-600 transition">
                        View Deal
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          <div className="p-4 border-t border-neutral-200 bg-neutral-50 text-center">
            <Button variant="link" className="text-primary hover:underline font-medium">
              See more providers in your area
            </Button>
          </div>
        </Card>
        
        <Card className="bg-white rounded-xl p-6 shadow-md border border-neutral-200 text-center">
          <h3 className="font-medium mb-4">Not seeing what you're looking for?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link href="/compare/electricity" className="py-3 px-4 border border-neutral-300 rounded-lg hover:bg-neutral-50 transition flex justify-center items-center">
              <i className="fas fa-bolt text-yellow-500 mr-2"></i>
              <span>Electricity Providers</span>
            </Link>
            <Link href="/compare/insurance" className="py-3 px-4 border border-neutral-300 rounded-lg hover:bg-neutral-50 transition flex justify-center items-center">
              <i className="fas fa-shield-alt text-red-500 mr-2"></i>
              <span>Home Insurance</span>
            </Link>
            <Link href="/compare/cleaning" className="py-3 px-4 border border-neutral-300 rounded-lg hover:bg-neutral-50 transition flex justify-center items-center">
              <i className="fas fa-broom text-green-500 mr-2"></i>
              <span>Cleaning Services</span>
            </Link>
          </div>
        </Card>
      </div>
    </section>
  );
}
