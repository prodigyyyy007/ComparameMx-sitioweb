import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function CtaSection() {
  const [zipCode, setZipCode] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [, navigate] = useLocation();

  const handleGetStarted = () => {
    if (zipCode && selectedService) {
      navigate(`/compare/${selectedService}?zip=${zipCode}`);
    } else if (zipCode) {
      navigate(`/compare?zip=${zipCode}`);
    } else if (selectedService) {
      navigate(`/compare/${selectedService}`);
    } else {
      navigate('/compare');
    }
  };

  return (
    <section className="py-16 bg-gradient-to-r from-primary to-accent text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Find the Best Services for Your Home?</h2>
          <p className="text-xl opacity-90 mb-8">Join thousands of homeowners who save time and money by comparing service options with HomeServiceCompare.</p>
          
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <div className="flex flex-col md:flex-row md:items-end gap-4">
              <div className="flex-grow">
                <Label htmlFor="zip-code-cta" className="block text-neutral-700 text-sm font-medium mb-2">Enter Your ZIP Code</Label>
                <Input 
                  type="text" 
                  id="zip-code-cta" 
                  placeholder="e.g., 90210" 
                  className="w-full p-3 border border-neutral-300 rounded-lg text-neutral-800"
                  value={zipCode}
                  onChange={(e) => setZipCode(e.target.value)}
                />
              </div>
              <div className="flex-grow">
                <Label htmlFor="service-type-cta" className="block text-neutral-700 text-sm font-medium mb-2">Service You're Interested In</Label>
                <Select value={selectedService} onValueChange={setSelectedService}>
                  <SelectTrigger id="service-type-cta" className="w-full p-3 border border-neutral-300 rounded-lg text-neutral-800 bg-white">
                    <SelectValue placeholder="Select a service" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="internet">Internet & Cable</SelectItem>
                    <SelectItem value="electricity">Electricity</SelectItem>
                    <SelectItem value="insurance">Home Insurance</SelectItem>
                    <SelectItem value="security">Home Security</SelectItem>
                    <SelectItem value="lawn">Lawn Care</SelectItem>
                    <SelectItem value="all">All Services</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleGetStarted}
                className="w-full md:w-auto px-6 py-3 bg-primary text-white rounded-lg font-medium hover:bg-primary-800 transition"
              >
                Get Started
              </Button>
            </div>
          </div>
          
          <p className="mt-6 text-sm opacity-80">No spam, ever. We respect your privacy and will never share your information.</p>
        </div>
      </div>
    </section>
  );
}
