import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FaqSection() {
  const faqs = [
    {
      question: "How does HomeServiceCompare make money?",
      answer: "We receive a commission from service providers when you sign up through our platform. This doesn't cost you anything extra - in fact, we often negotiate exclusive discounts for our users. Our recommendations are always based on value, quality, and user reviews, not on commission rates."
    },
    {
      question: "Are the prices shown the final prices I'll pay?",
      answer: "We show the most accurate pricing information available, including promotional rates and standard rates after promotions end. However, final prices may include taxes, fees, and equipment costs that vary by location. We always indicate when additional fees may apply and provide as much transparency as possible."
    },
    {
      question: "Can I compare services if I'm not a new homeowner?",
      answer: "Absolutely! While our platform is designed with new homeowners in mind, anyone can use HomeServiceCompare to find better deals on home services. Whether you're moving to a new address or simply looking to switch providers at your current home, our comparison tools can help you save money and find better services."
    },
    {
      question: "How often is the pricing information updated?",
      answer: "We update our pricing information at least monthly, and often more frequently when providers launch new promotions or change their plans. We work directly with service providers to ensure that we have the most current information available. If you ever notice outdated information, please let us know through our contact form."
    },
    {
      question: "Do you cover all locations in the United States?",
      answer: "We currently cover most major metropolitan areas and are continuously expanding our coverage to include more regions. Some rural areas may have limited service options available for comparison. When you enter your ZIP code, we'll show you all the options we have information for in your area."
    }
  ];

  return (
    <section id="faq" className="py-16 bg-neutral-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-neutral-600 max-w-3xl mx-auto">Get answers to common questions about our service and home services in general.</p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full divide-y divide-neutral-200">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-b-0 py-2">
                <AccordionTrigger className="text-left text-lg font-medium text-neutral-800 py-3">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-neutral-600 pt-1 pb-3">
                  <p>{faq.answer}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
        
        <div className="mt-10 text-center">
          <p className="text-neutral-600 mb-4">Don't see your question here?</p>
          <Link href="/contact">
            <Button className="px-6 py-3 bg-primary text-white rounded-lg font-medium hover:bg-primary-600 transition">
              Contact Us
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
