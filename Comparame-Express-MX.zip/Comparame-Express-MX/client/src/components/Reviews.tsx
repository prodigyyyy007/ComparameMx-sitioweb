import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { User } from "lucide-react";

export default function Reviews() {
  const reviews = [
    {
      id: 1,
      rating: 5.0,
      content: "As a first-time homeowner, I was overwhelmed by all the different services I needed to set up. HomeServiceCompare made it so easy to find the best deals in my area and saved me hours of research.",
      author: {
        name: "Sarah J.",
        location: "Portland, OR",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=40&h=40"
      }
    },
    {
      id: 2,
      rating: 4.7,
      content: "I was paying way too much for internet service until I used this site. I found a provider with twice the speed for $30 less per month! The comparison table made it easy to see all my options at once.",
      author: {
        name: "Michael T.",
        location: "Austin, TX",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=40&h=40"
      }
    },
    {
      id: 3,
      rating: 5.0,
      content: "The home insurance comparison tool saved us over $600 a year! We were able to find coverage that was both more comprehensive and less expensive than what we had before. Highly recommend!",
      author: {
        name: "James & Emma L.",
        location: "Charlotte, NC",
        avatar: "https://images.unsplash.com/photo-1548142813-c348350df52b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=40&h=40"
      }
    }
  ];

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={`star-${i}`} className="fas fa-star"></i>);
    }
    
    if (hasHalfStar) {
      stars.push(<i key="half-star" className="fas fa-star-half-alt"></i>);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star"></i>);
    }
    
    return stars;
  };

  return (
    <section id="reviews" className="py-16 bg-neutral-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">What Homeowners Are Saying</h2>
          <p className="text-neutral-600 max-w-3xl mx-auto">Read reviews from homeowners who've used our service to find the best providers.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review) => (
            <Card key={review.id} className="bg-white p-6 rounded-xl shadow-md border border-neutral-200">
              <CardContent className="p-0">
                <div className="flex items-center mb-4">
                  <div className="text-yellow-500 mr-2">
                    {renderStars(review.rating)}
                  </div>
                  <span className="font-semibold">{review.rating.toFixed(1)}</span>
                </div>
                <p className="text-neutral-700 mb-4">"{review.content}"</p>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-neutral-200 overflow-hidden mr-3">
                    {review.author.avatar ? (
                      <img 
                        src={review.author.avatar} 
                        alt={`${review.author.name} profile photo`} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="w-full h-full p-2" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium">{review.author.name}</div>
                    <div className="text-xs text-neutral-500">{review.author.location}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Link href="/reviews" className="inline-flex items-center text-primary font-medium hover:underline">
            Read more reviews
            <i className="fas fa-chevron-right ml-2 text-sm"></i>
          </Link>
        </div>
      </div>
    </section>
  );
}
