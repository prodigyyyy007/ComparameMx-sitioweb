import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, ArrowRight, Shield, Clock, Users } from "lucide-react";
import { useTranslation } from "react-i18next";

export default function Hero() {
  const [zipCode, setZipCode] = useState("");
  const { t } = useTranslation();

  const handleSearch = () => {
    if (zipCode.trim()) {
      window.location.href = `/compare?zip=${encodeURIComponent(zipCode)}`;
    }
  };

  const features = [
    {
      icon: Shield,
      title: "Confiable",
      subtitle: "Proveedores verificados"
    },
    {
      icon: Clock,
      title: "Rápido",
      subtitle: "Comparación en segundos"
    },
    {
      icon: Users,
      title: "Gratuito",
      subtitle: "Sin costos ocultos"
    }
  ];

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-16 pb-20">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      
      <div className="container mx-auto px-4 relative">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            {t('heroTitle')}
          </h1>
          
          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed max-w-3xl mx-auto">
            {t('heroSubtitle')}
          </p>
          
          {/* Search Box */}
          <div className="max-w-md mx-auto mb-12">
            <div className="flex gap-2 p-2 bg-white rounded-2xl shadow-lg border border-gray-100">
              <Input
                type="text"
                placeholder={t('zipCodePlaceholder')}
                value={zipCode}
                onChange={(e) => setZipCode(e.target.value)}
                className="flex-1 border-0 text-lg focus-visible:ring-0 focus-visible:ring-offset-0"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button 
                onClick={handleSearch}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 rounded-xl shadow-md"
              >
                <Search className="w-5 h-5 mr-2" />
                {t('getStartedBtn')}
              </Button>
            </div>
          </div>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button 
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl shadow-lg text-lg font-medium"
              onClick={handleSearch}
            >
              {t('getStartedBtn')}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-2 border-gray-300 hover:border-blue-600 hover:text-blue-600 px-8 py-3 rounded-xl text-lg font-medium"
            >
              {t('learnMoreBtn')}
            </Button>
          </div>
          
          {/* Trust Indicators */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-2xl mx-auto">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center justify-center space-x-3 p-4 bg-white/60 backdrop-blur rounded-2xl border border-white/20 shadow-sm">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl flex items-center justify-center">
                  <feature.icon className="w-5 h-5 text-blue-600" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-gray-900">{feature.title}</div>
                  <div className="text-sm text-gray-600">{feature.subtitle}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-2xl"></div>
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-gradient-to-br from-purple-400/20 to-blue-400/20 rounded-full blur-2xl"></div>
    </section>
  );
}