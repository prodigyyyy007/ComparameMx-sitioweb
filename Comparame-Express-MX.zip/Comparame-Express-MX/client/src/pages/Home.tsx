import SEO from "@/lib/seo";
import Hero from "@/components/Hero";
import ServiceCategories from "@/components/ServiceCategories";
import ComparisonTable from "@/components/ComparisonTable";
import HowItWorks from "@/components/HowItWorks";
import Reviews from "@/components/Reviews";
import ResourcesList from "@/components/ResourcesList";
import FaqSection from "@/components/FaqSection";
import CtaSection from "@/components/CtaSection";

export default function Home() {
  return (
    <>
      <SEO />
      <Hero />
      <ServiceCategories />
      <ComparisonTable />
      <HowItWorks />
      <Reviews />
      <ResourcesList />
      <FaqSection />
      <CtaSection />
    </>
  );
}
