import SEO from "@/lib/seo";
import ResourcesList from "@/components/ResourcesList";
import CtaSection from "@/components/CtaSection";

export default function Resources() {
  return (
    <>
      <SEO 
        title="Resources & Guides for New Homeowners"
        description="Helpful resources, guides, articles and tools for new homeowners. Learn how to save money on services and maintain your new home."
        keywords="homeowner resources, new home guides, homeowner tips, home maintenance checklist"
        ogType="website"
      />
      
      <div className="py-8 bg-white">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Resources for New Homeowners</h1>
          <p className="text-neutral-600 max-w-3xl">
            Helpful guides, articles, and tools to help you navigate homeownership and make the most of your new home.
          </p>
        </div>
      </div>
      
      <ResourcesList />
      <CtaSection />
    </>
  );
}
