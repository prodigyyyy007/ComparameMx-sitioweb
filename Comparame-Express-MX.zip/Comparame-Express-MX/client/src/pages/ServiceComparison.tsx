import { useParams, useLocation } from "wouter";
import SEO from "@/lib/seo";
import ComparisonTable from "@/components/ComparisonTable";
import CtaSection from "@/components/CtaSection";

export default function ServiceComparison() {
  const { service } = useParams<{ service?: string }>();
  const [location] = useLocation();
  
  // Extract ZIP code from URL if present
  const zip = new URLSearchParams(location.split("?")[1]).get("zip") || "";
  
  // Service name formatted for display
  const getServiceName = () => {
    if (!service) return "All Services";
    
    const services: Record<string, string> = {
      'internet': 'Internet Providers',
      'electricity': 'Electricity Providers',
      'water': 'Water Service Providers',
      'insurance': 'Home Insurance',
      'security': 'Home Security',
      'lawn': 'Lawn Care',
      'warranty': 'Home Warranty',
      'cleaning': 'Cleaning Services'
    };
    
    return services[service] || service.charAt(0).toUpperCase() + service.slice(1);
  };

  const serviceName = getServiceName();

  return (
    <>
      <SEO 
        title={`Compare ${serviceName} for New Homeowners`}
        description={`Compare ${serviceName.toLowerCase()} pricing, features, and reviews. Find the best deals for your new home.`}
        keywords={`compare ${serviceName.toLowerCase()}, ${service} comparison, best ${service} for new homeowners`}
        ogType="website"
      />
      
      <div className="py-8 bg-white">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Compare {serviceName}</h1>
          <p className="text-neutral-600 max-w-3xl">
            Find and compare the best {serviceName.toLowerCase()} for your home. 
            View side-by-side comparisons of prices, features, and customer reviews.
          </p>
        </div>
      </div>
      
      <ComparisonTable serviceType={service} zip={zip} />
      <CtaSection />
    </>
  );
}
