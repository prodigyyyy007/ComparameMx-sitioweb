import SEO from "@/lib/seo";
import ContactForm from "@/components/ContactForm";

export default function Contact() {
  return (
    <>
      <SEO 
        title="Contact Us"
        description="Contact HomeServiceCompare for help with finding and comparing home services for your new home."
        keywords="contact homeservicecompare, home services help, homeowner support"
        ogType="website"
      />
      
      <div className="py-8 bg-white">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Contact Us</h1>
          <p className="text-neutral-600 max-w-3xl">
            Have questions or need help? Our team is ready to assist you with finding the right services for your home.
          </p>
        </div>
      </div>
      
      <ContactForm />
    </>
  );
}
