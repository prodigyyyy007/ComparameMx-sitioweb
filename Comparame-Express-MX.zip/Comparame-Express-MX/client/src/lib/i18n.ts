import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  es: {
    translation: {
      // Navigation
      home: "Inicio",
      services: "Servicios",
      resources: "Recursos",
      contact: "Contacto",
      
      // Hero Section
      heroTitle: "Encuentra los Mejores Servicios para tu Hogar",
      heroSubtitle: "Compara precios, características y calificaciones de proveedores de servicios esenciales para propietarios en México",
      getStartedBtn: "Comenzar Comparación",
      learnMoreBtn: "Saber Más",
      
      // Service Categories
      serviceCategoriesTitle: "Servicios Esenciales para tu Hogar",
      serviceCategoriesSubtitle: "Compara y encuentra los mejores proveedores para todos tus servicios del hogar",
      
      // Categories
      internetTitle: "Internet y Cable",
      internetDesc: "Compara paquetes de internet de alta velocidad y TV de proveedores en tu área.",
      insuranceTitle: "Seguro de Hogar",
      insuranceDesc: "Encuentra pólizas de seguro de hogar asequibles con la cobertura que necesitas.",
      electricityTitle: "Servicios Públicos",
      electricityDesc: "Compara proveedores de electricidad y gas para encontrar las mejores tarifas.",
      securityTitle: "Seguridad del Hogar",
      securityDesc: "Protege tu nuevo hogar con sistemas de seguridad y monitoreo mejor calificados.",
      lawnTitle: "Jardín y Paisajismo",
      lawnDesc: "Encuentra servicios confiables de cuidado del césped y paisajismo en tu vecindario.",
      warrantyTitle: "Garantía del Hogar",
      warrantyDesc: "Protege sistemas principales y electrodomésticos con planes de garantía integrales.",
      
      // Comparison Table
      provider: "Proveedor",
      type: "Tipo",
      price: "Precio",
      speed: "Velocidad",
      dataCap: "Límite de Datos",
      rating: "Calificación",
      compareBtn: "Comparar",
      viewDetailsBtn: "Ver Detalles",
      
      // How It Works
      howItWorksTitle: "Cómo Funciona",
      step1Title: "Busca",
      step1Desc: "Ingresa tu código postal para encontrar servicios disponibles en tu área",
      step2Title: "Compara",
      step2Desc: "Revisa precios, características y calificaciones lado a lado",
      step3Title: "Elige",
      step3Desc: "Contacta directamente al proveedor que mejor se adapte a tus necesidades",
      
      // Reviews
      reviewsTitle: "Lo que Dicen Nuestros Usuarios",
      
      // FAQ
      faqTitle: "Preguntas Frecuentes",
      faq1Q: "¿Es gratis usar Comparame Express Mx?",
      faq1A: "Sí, nuestro servicio de comparación es completamente gratuito para los consumidores.",
      faq2Q: "¿Con qué frecuencia se actualizan los precios?",
      faq2A: "Actualizamos los precios y ofertas semanalmente para asegurar información precisa.",
      faq3Q: "¿Puedo cambiar de proveedor en cualquier momento?",
      faq3A: "Los términos de cambio dependen del contrato de cada proveedor. Te ayudamos a entender las condiciones.",
      
      // Contact Form
      contactTitle: "Contáctanos",
      contactSubtitle: "¿Tienes preguntas? Nos encantaría ayudarte.",
      nameLabel: "Nombre",
      emailLabel: "Email",
      phoneLabel: "Teléfono",
      messageLabel: "Mensaje",
      sendMessageBtn: "Enviar Mensaje",
      messageSent: "¡Mensaje enviado exitosamente!",
      
      // Footer
      footerTagline: "Tu guía confiable para servicios del hogar en México",
      quickLinks: "Enlaces Rápidos",
      serviceLinks: "Servicios",
      supportLinks: "Soporte",
      privacyPolicy: "Política de Privacidad",
      termsOfService: "Términos de Servicio",
      
      // Common
      loading: "Cargando...",
      error: "Error",
      tryAgain: "Intentar de nuevo",
      noResults: "No se encontraron resultados",
      zipCodePlaceholder: "Ingresa tu código postal"
    }
  },
  en: {
    translation: {
      // Navigation
      home: "Home",
      services: "Services", 
      resources: "Resources",
      contact: "Contact",
      
      // Hero Section
      heroTitle: "Find the Best Services for Your Home",
      heroSubtitle: "Compare prices, features, and ratings from essential service providers for homeowners in Mexico",
      getStartedBtn: "Start Comparing",
      learnMoreBtn: "Learn More",
      
      // Service Categories
      serviceCategoriesTitle: "Essential Home Services",
      serviceCategoriesSubtitle: "Compare and find the best providers for all your home service needs",
      
      // Categories
      internetTitle: "Internet & Cable",
      internetDesc: "Compare high-speed internet and TV packages from providers in your area.",
      insuranceTitle: "Home Insurance",
      insuranceDesc: "Find affordable home insurance policies with the coverage you need.",
      electricityTitle: "Energy Utilities",
      electricityDesc: "Compare electricity and gas providers to find the best rates and plans.",
      securityTitle: "Home Security",
      securityDesc: "Protect your new home with top-rated security systems and monitoring.",
      lawnTitle: "Lawn & Garden",
      lawnDesc: "Find reliable lawn care and landscaping services in your neighborhood.",
      warrantyTitle: "Home Warranty",
      warrantyDesc: "Protect major systems and appliances with comprehensive warranty plans.",
      
      // Comparison Table
      provider: "Provider",
      type: "Type",
      price: "Price",
      speed: "Speed",
      dataCap: "Data Cap",
      rating: "Rating",
      compareBtn: "Compare",
      viewDetailsBtn: "View Details",
      
      // How It Works
      howItWorksTitle: "How It Works",
      step1Title: "Search",
      step1Desc: "Enter your zip code to find services available in your area",
      step2Title: "Compare",
      step2Desc: "Review prices, features, and ratings side by side",
      step3Title: "Choose",
      step3Desc: "Contact the provider that best fits your needs directly",
      
      // Reviews
      reviewsTitle: "What Our Users Say",
      
      // FAQ
      faqTitle: "Frequently Asked Questions",
      faq1Q: "Is Comparame Express Mx free to use?",
      faq1A: "Yes, our comparison service is completely free for consumers.",
      faq2Q: "How often are prices updated?",
      faq2A: "We update prices and offers weekly to ensure accurate information.",
      faq3Q: "Can I switch providers anytime?",
      faq3A: "Switching terms depend on each provider's contract. We help you understand the conditions.",
      
      // Contact Form
      contactTitle: "Contact Us",
      contactSubtitle: "Have questions? We'd love to help.",
      nameLabel: "Name",
      emailLabel: "Email",
      phoneLabel: "Phone",
      messageLabel: "Message",
      sendMessageBtn: "Send Message",
      messageSent: "Message sent successfully!",
      
      // Footer
      footerTagline: "Your trusted guide for home services in Mexico",
      quickLinks: "Quick Links",
      serviceLinks: "Services",
      supportLinks: "Support",
      privacyPolicy: "Privacy Policy",
      termsOfService: "Terms of Service",
      
      // Common
      loading: "Loading...",
      error: "Error",
      tryAgain: "Try again",
      noResults: "No results found",
      zipCodePlaceholder: "Enter your zip code"
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'es',
    debug: false,
    interpolation: {
      escapeValue: false,
    },
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage'],
    },
  });

export default i18n;