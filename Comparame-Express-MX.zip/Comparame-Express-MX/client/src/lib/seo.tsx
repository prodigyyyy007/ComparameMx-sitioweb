import { ReactNode } from "react";
import { Helmet } from 'react-helmet';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  ogType?: string;
  ogUrl?: string;
  children?: ReactNode;
}

export default function SEO({
  title = "HomeServiceCompare - Compare Services for New Homeowners",
  description = "Find and compare the best home services for new homeowners. Compare prices on utilities, insurance, home maintenance services and more.",
  keywords = "home services, homeowner services, compare utilities, home insurance, home maintenance",
  ogImage = "https://homeservicecompare.com/og-image.jpg",
  ogType = "website",
  ogUrl = "https://homeservicecompare.com",
  children,
}: SEOProps) {
  const siteTitle = "HomeServiceCompare";
  const fullTitle = title === siteTitle ? title : `${title} | ${siteTitle}`;

  return (
    <Helmet>
      {/* Primary Meta Tags */}
      <title>{fullTitle}</title>
      <meta name="title" content={fullTitle} />
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />
      
      {/* Open Graph / Facebook */}
      <meta property="og:type" content={ogType} />
      <meta property="og:url" content={ogUrl} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={ogImage} />
      
      {/* Twitter */}
      <meta property="twitter:card" content="summary_large_image" />
      <meta property="twitter:url" content={ogUrl} />
      <meta property="twitter:title" content={fullTitle} />
      <meta property="twitter:description" content={description} />
      <meta property="twitter:image" content={ogImage} />
      
      {/* Structured Data */}
      <script type="application/ld+json">
        {`
          {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "HomeServiceCompare",
            "url": "https://homeservicecompare.com",
            "potentialAction": {
              "@type": "SearchAction",
              "target": "https://homeservicecompare.com/compare?s={search_term_string}",
              "query-input": "required name=search_term_string"
            }
          }
        `}
      </script>
      
      {children}
    </Helmet>
  );
}
