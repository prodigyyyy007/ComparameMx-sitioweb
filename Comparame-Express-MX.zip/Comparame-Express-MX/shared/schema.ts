import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Service categories
export const serviceCategories = pgTable("service_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  icon: text("icon").notNull(),
  iconColor: text("icon_color").notNull(),
  description: text("description").notNull(),
  order: integer("order").notNull().default(0),
});

export const insertServiceCategorySchema = createInsertSchema(serviceCategories).pick({
  name: true,
  slug: true,
  icon: true,
  iconColor: true,
  description: true,
  order: true,
});

export type InsertServiceCategory = z.infer<typeof insertServiceCategorySchema>;
export type ServiceCategory = typeof serviceCategories.$inferSelect;

// Service providers
export const serviceProviders = pgTable("service_providers", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  icon: text("icon").notNull(),
  iconColor: text("icon_color").notNull(),
  price: text("price").notNull(),
  priceNote: text("price_note"),
  speed: text("speed"),
  speedNote: text("speed_note"),
  dataCap: text("data_cap"),
  rating: integer("rating").notNull(),
  zipCodes: text("zip_codes").array(),
});

export const insertServiceProviderSchema = createInsertSchema(serviceProviders).pick({
  categoryId: true,
  name: true,
  type: true,
  icon: true,
  iconColor: true,
  price: true,
  priceNote: true,
  speed: true,
  speedNote: true,
  dataCap: true,
  rating: true,
  zipCodes: true,
});

export type InsertServiceProvider = z.infer<typeof insertServiceProviderSchema>;
export type ServiceProvider = typeof serviceProviders.$inferSelect;

// Contact messages
export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  isRead: boolean("is_read").notNull().default(false),
});

export const insertContactMessageSchema = createInsertSchema(contactMessages).pick({
  name: true,
  email: true,
  subject: true,
  message: true,
});

export type InsertContactMessage = z.infer<typeof insertContactMessageSchema>;
export type ContactMessage = typeof contactMessages.$inferSelect;
